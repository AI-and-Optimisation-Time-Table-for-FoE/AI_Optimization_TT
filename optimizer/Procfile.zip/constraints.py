from ortools.sat.python import cp_model
from models import OptimizeRequest, TimetableEntryOutput
from typing import List, Tuple

def solve_hard_constraints_internal(req: OptimizeRequest, relaxed: bool = False) -> Tuple[str, List[TimetableEntryOutput]]:
    model = cp_model.CpModel()
    
    # 1. Prepare data
    # Flat list of sessions to schedule. A session is: (batchModuleId, lecturerId, preferredHallId, index)
    sessions = []
    core_sessions = []
    elective_sessions = []
    for mod in req.modules:
        lec_ids = list(mod.lecturerIds) if mod.lecturerIds else [mod.lecturerId]
        name = mod.moduleName.lower()
        code = mod.moduleCode.lower()
        is_elective = "(te)" in name or "elective" in name or "(e)" in name or "te" in code
        for i in range(mod.sessionsNeeded):
            s_idx = len(sessions)
            sessions.append({
                "batchModuleId": mod.batchModuleId,
                "moduleCode": mod.moduleCode,
                "moduleName": mod.moduleName,
                "lecturerIds": lec_ids,
                "preferredHallId": mod.preferredHallId,
                "studentCount": mod.studentCount,
                "needsComputer": mod.needsComputer,
                "index": i
            })
            if is_elective:
                elective_sessions.append(s_idx)
            else:
                core_sessions.append(s_idx)
            
    num_sessions = len(sessions)
    if num_sessions == 0:
        return "success", []
        
    slots = req.timeSlots
    halls = req.halls
    
    # Variables: x[s, t, h] = 1 if session s is assigned to slot t in hall h
    x = {}
    for s_idx in range(num_sessions):
        for t in slots:
            for h in halls:
                x[s_idx, t.slotId, h.hallId] = model.NewBoolVar(f'x_{s_idx}_{t.slotId}_{h.hallId}')
                
    penalty_terms = []
    
    # 2. Hard Constraints
    
    # H1: Each session must be scheduled in exactly one slot and one hall
    for s_idx in range(num_sessions):
        model.Add(sum(x[s_idx, t.slotId, h.hallId] for t in slots for h in halls) == 1)
        
    # H2: Strict Hall Rules (Capacity, Computer Needs, 27th Batch, Admin Preference)
    for s_idx, session in enumerate(sessions):
        req_capacity = session.get("studentCount") or req.studentCount
        pref_hall_id = session.get("preferredHallId")
        needs_computer = session.get("needsComputer")
        
        is_27th_batch = (req.batchId == 1)
        
        for h in halls:
            can_use = True
            
            if pref_hall_id is not None:
                if h.hallId != pref_hall_id:
                    can_use = False
            else:
                if is_27th_batch:
                    if needs_computer:
                        if h.hallId != 51: # NCC
                            can_use = False
                    else:
                        if h.hallId != 35: # Auditorium
                            can_use = False
                else:
                    if h.capacity < req_capacity:
                        can_use = False
                    if needs_computer and not getattr(h, 'isComputerLab', False):
                        can_use = False
                        
            if not can_use:
                for t in slots:
                    model.Add(x[s_idx, t.slotId, h.hallId] == 0)
                    
    # H1: No overlapping lectures for the requested cohort (ALL sessions must be mutually exclusive)
    # The payload contains exactly the cohort's modules, so NO sessions should overlap (including TEs).
    for t in slots:
        model.Add(sum(x[s_idx, t.slotId, h.hallId] for s_idx in range(num_sessions) for h in halls if (s_idx, t.slotId, h.hallId) in x) <= 1)

    # H16: Respect Computer Lab requirement (unless admin explicitly set a preferred hall)
    for s_idx, session in enumerate(sessions):
        needs_comp = session.get("needsComputer", False)
        has_preferred = session.get("preferredHallId") is not None
        if needs_comp and not has_preferred:
            for h in halls:
                if not getattr(h, "isComputerLab", False):
                    for t in slots:
                        if (s_idx, t.slotId, h.hallId) in x:
                            model.Add(x[s_idx, t.slotId, h.hallId] == 0)


    # H14: No hall double-booking (at most one session per hall per slot)
    for t in slots:
        for h in halls:
            model.Add(sum(x[s_idx, t.slotId, h.hallId] for s_idx in range(num_sessions) if (s_idx, t.slotId, h.hallId) in x) <= 1)

    # H15: No lecturer double-booking (a lecturer cannot teach more than one session at the same time)
    # Gather all unique lecturer IDs from this request's sessions
    all_lecturer_ids = set()
    for session in sessions:
        all_lecturer_ids.update(session.get("lecturerIds", []))
        
    for t in slots:
        for lec_id in all_lecturer_ids:
            lec_sessions = [
                s_idx for s_idx, session in enumerate(sessions)
                if lec_id in session.get("lecturerIds", [])
            ]
            if len(lec_sessions) > 1:
                # Sum of all sessions taught by this lecturer in this slot across all halls must be <= 1
                model.Add(sum(x[s_idx, t.slotId, h.hallId] for s_idx in lec_sessions for h in halls if (s_idx, t.slotId, h.hallId) in x) <= 1)

    # H4: Respect lecturer unavailability (double booking + unavailable slots)
    for s_idx, session in enumerate(sessions):
        for lec_id in session.get("lecturerIds", []):
            lec_id_str = str(lec_id)
            unavail_slots = req.lecturerUnavailability.get(lec_id_str, [])
            for t_id in unavail_slots:
                for h in halls:
                    if (s_idx, t_id, h.hallId) in x:
                        if relaxed:
                            penalty_terms.append(1000 * x[s_idx, t_id, h.hallId])
                        else:
                            model.Add(x[s_idx, t_id, h.hallId] == 0)
                    
    # H5: Respect hall unavailability (double booking + unavailable slots)
    for h in halls:
        h_id_str = str(h.hallId)
        unavail_slots = req.hallUnavailability.get(h_id_str, [])
        for t_id in unavail_slots:
            for s_idx in range(num_sessions):
                if (s_idx, t_id, h.hallId) in x:
                    if relaxed:
                        penalty_terms.append(1000 * x[s_idx, t_id, h.hallId])
                    else:
                        model.Add(x[s_idx, t_id, h.hallId] == 0)
                    
    # H6: Respect batch lab schedule (blocked slots for this batch's modules)
    for s_idx, session in enumerate(sessions):
        bm_id_str = str(session["batchModuleId"])
        blocked_slots = req.batchLabSchedules.get(bm_id_str, [])
        for t_id in blocked_slots:
            for h in halls:
                if (s_idx, t_id, h.hallId) in x:
                    model.Add(x[s_idx, t_id, h.hallId] == 0)
                    
    # H7: Lunch break constraint (using batch's custom lunch break)
    lunch_start = req.lunchStartTime[:5] if req.lunchStartTime else "12:30"
    lunch_end = req.lunchEndTime[:5] if req.lunchEndTime else "13:30"
    
    for t in slots:
        slot_start = t.startTime[:5]
        slot_end = t.endTime[:5]
        # Check if the slot overlaps with the lunch break
        if slot_start < lunch_end and slot_end > lunch_start:
            for s_idx in range(num_sessions):
                for h in halls:
                    if (s_idx, t.slotId, h.hallId) in x:
                        model.Add(x[s_idx, t.slotId, h.hallId] == 0)
                        
    # H12: Wednesday Common Hours constraint (Wednesday 14:30 to 16:30)
    for t in slots:
        if t.dayOfWeek == "Wednesday":
            slot_start = t.startTime[:5]
            slot_end = t.endTime[:5]
            if slot_start < "16:30" and slot_end > "14:30":
                for s_idx in range(num_sessions):
                    for h in halls:
                        if (s_idx, t.slotId, h.hallId) in x:
                            model.Add(x[s_idx, t.slotId, h.hallId] == 0)
                        
    # H13: Friday after 4:30 PM constraint (Friday 16:30 onwards is blocked)
    for t in slots:
        if t.dayOfWeek == "Friday":
            slot_start = t.startTime[:5]
            if slot_start >= "16:30":
                for s_idx in range(num_sessions):
                    for h in halls:
                        if (s_idx, t.slotId, h.hallId) in x:
                            model.Add(x[s_idx, t.slotId, h.hallId] == 0)
                        
    slots_by_day = {}
    for t in slots:
        slots_by_day.setdefault(t.dayOfWeek, []).append(t.slotId)
        
    max_hours_limit = 16
    
    # Group sessions by department for H8
    dept_to_sessions = {}
    for s_idx in range(num_sessions):
        code = sessions[s_idx]["moduleCode"]
        dept = code[:2].upper()
        if dept == 'IS':
            # IS modules are shared, so they count towards all departments.
            # We'll handle this by adding them to every department's limit below.
            pass
        else:
            dept_to_sessions.setdefault(dept, []).append(s_idx)
            
    is_sessions = [s_idx for s_idx in range(num_sessions) if sessions[s_idx]["moduleCode"].startswith("IS")]
    
    for day, day_slots in slots_by_day.items():
        for dept, d_sessions in dept_to_sessions.items():
            # A department's total daily sessions (including shared IS sessions) cannot exceed max_hours_limit
            dept_group = d_sessions + is_sessions
            model.Add(sum(x[s_idx, t_id, h.hallId] for s_idx in dept_group for t_id in day_slots for h in halls if (s_idx, t_id, h.hallId) in x) <= max_hours_limit)
        
        # If there are ONLY IS modules (e.g. no specific departments)
        if not dept_to_sessions and is_sessions:
            model.Add(sum(x[s_idx, t_id, h.hallId] for s_idx in is_sessions for t_id in day_slots for h in halls if (s_idx, t_id, h.hallId) in x) <= max_hours_limit)
        

    # H13: Friday after 4:30 PM constraint (Friday 16:30 onwards is blocked)
    for t in slots:
        if t.dayOfWeek == "Friday":
            slot_start = t.startTime[:5]
            if slot_start >= "16:30":
                for s_idx in range(num_sessions):
                    for h in halls:
                        if (s_idx, t.slotId, h.hallId) in x:
                            model.Add(x[s_idx, t.slotId, h.hallId] == 0)

    # H11: 3-Credit (3-Hour) Split Constraint
    # Group session indices by batchModuleId
    bm_session_indices = {}
    for s_idx, session in enumerate(sessions):
        bm_session_indices.setdefault(session["batchModuleId"], []).append(s_idx)
        
    # Group time slots by day
    slots_by_day_obj = {}
    for t in slots:
        slots_by_day_obj.setdefault(t.dayOfWeek, []).append(t)
        
    # Helper binary variable: w[s, t.slotId] = sum(x[s, t.slotId, h.hallId] for h in halls)
    w = {}
    for s_idx in range(num_sessions):
        for t in slots:
            w[s_idx, t.slotId] = model.NewBoolVar(f'w_{s_idx}_{t.slotId}')
            model.Add(w[s_idx, t.slotId] == sum(x[s_idx, t.slotId, h.hallId] for h in halls if (s_idx, t.slotId, h.hallId) in x))
            
    for bm_id, s_indices in bm_session_indices.items():
        if len(s_indices) == 2:
            is_two_days = []
            
            for day, day_slots in slots_by_day_obj.items():
                is_zero = model.NewBoolVar(f'is_zero_2c_{bm_id}_{day}')
                is_one = model.NewBoolVar(f'is_one_2c_{bm_id}_{day}')
                is_two = model.NewBoolVar(f'is_two_2c_{bm_id}_{day}')
                
                is_two_days.append(is_two)
                
                sum_slots = sum(w[s_idx, t.slotId] for s_idx in s_indices for t in day_slots)
                
                model.Add(is_zero + is_one + is_two == 1)
                model.Add(sum_slots == 0 * is_zero + 1 * is_one + 2 * is_two)
                
                sorted_day_slots = sorted(day_slots, key=lambda slot: slot.slotNumber)
                
                v = {}
                for t in sorted_day_slots:
                    v[t.slotId] = model.NewBoolVar(f'v_2c_{bm_id}_{day}_{t.slotId}')
                    model.Add(v[t.slotId] == sum(w[s_idx, t.slotId] for s_idx in s_indices))
                    
                pairs = []
                for idx in range(len(sorted_day_slots) - 1):
                    t1 = sorted_day_slots[idx]
                    t2 = sorted_day_slots[idx+1]
                    
                    t1_end = t1.endTime[:5]
                    t2_start = t2.startTime[:5]
                    if t1_end == t2_start:
                        pair_var = model.NewBoolVar(f'pair_2c_{bm_id}_{day}_{t1.slotId}_{t2.slotId}')
                        model.AddBoolAnd([v[t1.slotId], v[t2.slotId]]).OnlyEnforceIf(pair_var)
                        model.Add(v[t1.slotId] + v[t2.slotId] <= 1).OnlyEnforceIf(pair_var.Not())
                        pairs.append(pair_var)
                        
                if pairs:
                    model.Add(sum(pairs) == 1).OnlyEnforceIf(is_two)
                else:
                    model.Add(is_two == 0)
                    
            if not relaxed:
                model.Add(sum(is_two_days) == 1)

        elif len(s_indices) == 3:
            is_one_days = []
            is_two_days = []
            
            for day, day_slots in slots_by_day_obj.items():
                is_zero = model.NewBoolVar(f'is_zero_3c_{bm_id}_{day}')
                is_one = model.NewBoolVar(f'is_one_3c_{bm_id}_{day}')
                is_two = model.NewBoolVar(f'is_two_3c_{bm_id}_{day}')
                is_three = model.NewBoolVar(f'is_three_3c_{bm_id}_{day}')
                
                is_one_days.append(is_one)
                is_two_days.append(is_two)
                
                # Sum of sessions of this module on this day
                sum_slots = sum(w[s_idx, t.slotId] for s_idx in s_indices for t in day_slots)
                
                # Connect sum_slots to indicator variables
                model.Add(is_zero + is_one + is_two + is_three == 1)
                model.Add(sum_slots == 0 * is_zero + 1 * is_one + 2 * is_two + 3 * is_three)
                
                # Consecutive slots constraint for the day with 2 sessions
                sorted_day_slots = sorted(day_slots, key=lambda slot: slot.slotNumber)
                
                v = {}
                for t in sorted_day_slots:
                    v[t.slotId] = model.NewBoolVar(f'v_{bm_id}_{day}_{t.slotId}')
                    model.Add(v[t.slotId] == sum(w[s_idx, t.slotId] for s_idx in s_indices))
                    
                pairs = []
                for idx in range(len(sorted_day_slots) - 1):
                    t1 = sorted_day_slots[idx]
                    t2 = sorted_day_slots[idx+1]
                    
                    t1_end = t1.endTime[:5]
                    t2_start = t2.startTime[:5]
                    if t1_end == t2_start:
                        pair_var = model.NewBoolVar(f'pair_{bm_id}_{day}_{t1.slotId}_{t2.slotId}')
                        # pair_var <=> (v[t1.slotId] AND v[t2.slotId])
                        model.AddBoolAnd([v[t1.slotId], v[t2.slotId]]).OnlyEnforceIf(pair_var)
                        model.Add(v[t1.slotId] + v[t2.slotId] <= 1).OnlyEnforceIf(pair_var.Not())
                        pairs.append(pair_var)
                        
                if pairs:
                    model.Add(sum(pairs) == 1).OnlyEnforceIf(is_two)
                else:
                    model.Add(is_two == 0)
                    
            # Enforce exactly one day has 1 session, and exactly one day has 2 sessions
            if not relaxed:
                model.Add(sum(is_one_days) == 1)
                model.Add(sum(is_two_days) == 1)

        elif len(s_indices) == 4:
            is_two_days = []
            
            for day, day_slots in slots_by_day_obj.items():
                is_zero = model.NewBoolVar(f'is_zero_4c_{bm_id}_{day}')
                is_one = model.NewBoolVar(f'is_one_4c_{bm_id}_{day}')
                is_two = model.NewBoolVar(f'is_two_4c_{bm_id}_{day}')
                is_three = model.NewBoolVar(f'is_three_4c_{bm_id}_{day}')
                is_four = model.NewBoolVar(f'is_four_4c_{bm_id}_{day}')
                
                is_two_days.append(is_two)
                
                # Sum of sessions of this module on this day
                sum_slots = sum(w[s_idx, t.slotId] for s_idx in s_indices for t in day_slots)
                
                # Connect sum_slots to indicator variables
                model.Add(is_zero + is_one + is_two + is_three + is_four == 1)
                model.Add(sum_slots == 0 * is_zero + 1 * is_one + 2 * is_two + 3 * is_three + 4 * is_four)
                
                # Consecutive slots constraint for the day with 2 sessions
                sorted_day_slots = sorted(day_slots, key=lambda slot: slot.slotNumber)
                
                v = {}
                for t in sorted_day_slots:
                    v[t.slotId] = model.NewBoolVar(f'v_4c_{bm_id}_{day}_{t.slotId}')
                    model.Add(v[t.slotId] == sum(w[s_idx, t.slotId] for s_idx in s_indices))
                    
                pairs = []
                for idx in range(len(sorted_day_slots) - 1):
                    t1 = sorted_day_slots[idx]
                    t2 = sorted_day_slots[idx+1]
                    
                    t1_end = t1.endTime[:5]
                    t2_start = t2.startTime[:5]
                    if t1_end == t2_start:
                        pair_var = model.NewBoolVar(f'pair_4c_{bm_id}_{day}_{t1.slotId}_{t2.slotId}')
                        # pair_var <=> (v[t1.slotId] AND v[t2.slotId])
                        model.AddBoolAnd([v[t1.slotId], v[t2.slotId]]).OnlyEnforceIf(pair_var)
                        model.Add(v[t1.slotId] + v[t2.slotId] <= 1).OnlyEnforceIf(pair_var.Not())
                        pairs.append(pair_var)
                        
                if pairs:
                    model.Add(sum(pairs) == 1).OnlyEnforceIf(is_two)
                else:
                    model.Add(is_two == 0)
                    
            if not relaxed:
                model.Add(sum(is_two_days) == 2)

    # Objective: Guide CP-SAT toward a balanced, student-friendly initial solution.
    # Goal: sessions spread across morning AND afternoon, nothing crammed into one block.
    # Cost design:
    #   - Early morning (08:30-10:30): low cost (10)          ← good morning sessions
    #   - Late morning  (10:30-12:30): medium cost (15)       ← still fine, slight spread push
    #   - Lunch boundary (12:30-13:30): very high cost (80)   ← already a hard constraint block
    #   - Afternoon     (13:30-15:30): low cost (10)          ← equally good as morning
    #   - Late afternoon(15:30-16:30): medium cost (20)       ← slightly discouraged
    #   - After 4:30 PM (16:30+):      very high cost (100)   ← strongly avoid
    # The near-equal morning/afternoon costs ensure the solver picks a natural mix.
    # The GA then fine-tunes for exactly balanced distribution (S6) and max 3 consecutive (S8).
    objective_terms = []
    late_vars = []
    for s_idx in range(num_sessions):
        for t in slots:
            for h in halls:
                if (s_idx, t.slotId, h.hallId) not in x:
                    continue
                var = x[s_idx, t.slotId, h.hallId]
                start = t.startTime[:5]
                if start >= "16:30":
                    if t.dayOfWeek == "Wednesday":
                        cost = 3000  # Extremely high cost to avoid Wednesday late slot (after common hours)
                    else:
                        cost = 1000  # Base cost for late slot (strongly avoid 4:30 to 5:30)
                    late_vars.append(var)
                elif start >= "15:30":
                    cost = 100   # 3:30-4:30 PM — expensive (soft preference)
                elif start >= "13:30":
                    cost = 10   # Afternoon 1:30-3:30 PM — equally preferred as morning
                elif start >= "12:30":
                    cost = 500   # Lunch slot 12:30-13:30 — almost blocked
                elif start >= "10:30":
                    cost = 15   # Late morning — slight nudge to not over-pack
                else:
                    cost = 10   # Early morning 08:30-10:30 — preferred
                    
                # Penalize using unnecessarily large halls
                student_count = sessions[s_idx].get("studentCount") or 0
                capacity_waste = max(0, h.capacity - student_count)
                # Add the wasted seats as a direct cost to strongly discourage huge halls for small classes
                cost += capacity_waste
                
                objective_terms.append(cost * var)

    # Penalise if we have more than 1 late lecture per week
    if late_vars:
        num_late = model.NewIntVar(0, len(late_vars), 'num_late')
        model.Add(num_late == sum(late_vars))
        excess_late = model.NewIntVar(0, len(late_vars), 'excess_late')
        model.Add(excess_late >= num_late - 1)
        model.Add(excess_late >= 0)
        objective_terms.append(500 * excess_late)

    if objective_terms or penalty_terms:
        model.Minimize(sum(objective_terms) + sum(penalty_terms))

    # Solve
    solver = cp_model.CpSolver()
    solver.parameters.max_time_in_seconds = 60.0
    solver.parameters.log_search_progress = True
    status = solver.Solve(model)
    
    if status == cp_model.FEASIBLE or status == cp_model.OPTIMAL:
        schedule = []
        for s_idx, session in enumerate(sessions):
            for t in slots:
                for h in halls:
                    if solver.BooleanValue(x[s_idx, t.slotId, h.hallId]):
                        schedule.append(TimetableEntryOutput(
                            batchModuleId=session["batchModuleId"],
                            slotId=t.slotId,
                            hallId=h.hallId
                        ))
        return "success", schedule
    else:
        return "infeasible", []

def solve_hard_constraints(req: OptimizeRequest) -> Tuple[str, List[TimetableEntryOutput]]:
    status, schedule = solve_hard_constraints_internal(req, relaxed=False)
    if status == "success":
        return status, schedule
    print("Baseline constraints infeasible. Retrying with relaxed lecturer/hall unavailability...")
    return solve_hard_constraints_internal(req, relaxed=True)
